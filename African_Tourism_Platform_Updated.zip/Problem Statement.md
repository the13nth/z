
# Problem Statement

## Tourists
- Lack of consolidated travel information about Africa.
- Fragmentation of available information makes travel planning difficult.

## Sellers
- Limited channels for selling products to tourists.
- Difficulty in transporting products to accessible markets.
